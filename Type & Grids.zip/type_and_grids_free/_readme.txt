Type & Grids v3.0.0
www.typeandgrids.com
hello@typeandgrids.com


------------------------
GETTING STARTED GUIDE
------------------------
1) Move the unzipped folder to a location on your computer where you want to store your site.

2) Open "index.html" in your web browser.

3) Next, open "index.html" in your text editor. Locate the following lines of code near the top of the page:

<link rel="stylesheet" href="css/themes/type_05.css"> 
<link rel="stylesheet" href="css/themes/color_06.css">

4) Try changing the number "05" to "08" and the number "06" to "13". Save the page in your text editor and then refresh the page in your web browser to see the results.

5) Continue to scroll through "index.html" and edit all of the text to add your own content. Everything should be fairly intuitive and self-explanatory.

6) Finally, be sure to read through the FAQ as it contains lots of helpful tips.
http://www.typeandgrids.com/support


------------------------
TERMS OF USE
------------------------
Type & Grids products may be used in any kind of personal and/or commercial project. Each purchase provides a single user, single website license. Using Type & Grids on multiple sites will require a new purchase for each site it is used on. Type & Grids products may not be redistributed or resold to other companies or third parties.


Copyright 2013 Jeremiah Shoaf Design LLC. All rights reserved.